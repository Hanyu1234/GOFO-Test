import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

def setup_database():
    """创建SQLite数据库并生成模拟数据"""
    
    print("🚀 开始设置数据库...")
    
    # 连接SQLite数据库（会自动创建文件）
    conn = sqlite3.connect('logistics.db')
    cursor = conn.cursor()
    
    # 创建站点表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sites (
            site_id TEXT PRIMARY KEY,
            site_name TEXT NOT NULL,
            manager TEXT,
            region TEXT
        )
    ''')
    
    # 创建配送记录表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS delivery_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date DATE NOT NULL,
            site_id TEXT NOT NULL,
            rider_id TEXT,
            total_orders INTEGER NOT NULL,
            completed_orders INTEGER NOT NULL,
            rejected_orders INTEGER NOT NULL,
            on_time_orders INTEGER NOT NULL,
            total_cost REAL NOT NULL
        )
    ''')
    
    # 清空现有数据
    cursor.execute('DELETE FROM sites')
    cursor.execute('DELETE FROM delivery_records')
    
    # 插入站点数据
    sites = [
        ('site_a', '北京朝阳站', '张三', '华北'),
        ('site_b', '上海浦东站', '李四', '华东'), 
        ('site_c', '广州天河站', '王五', '华南')
    ]
    
    cursor.executemany('INSERT INTO sites VALUES (?, ?, ?, ?)', sites)
    
    # 生成30天的模拟数据
    delivery_data = []
    for day in range(30, 0, -1):
        current_date = (datetime.now() - timedelta(days=day)).strftime('%Y-%m-%d')
        
        for site_id, site_name, manager, region in sites:
            total_orders = np.random.randint(80, 150)
            completed_orders = int(total_orders * np.random.uniform(0.95, 0.99))
            rejected_orders = int(total_orders * np.random.uniform(0.005, 0.03))
            on_time_orders = int(completed_orders * np.random.uniform(0.92, 0.97))
            total_cost = round(np.random.uniform(600, 900), 2)
            rider_id = f'rider_{site_id}_{np.random.randint(1, 4)}'
            
            delivery_data.append((
                current_date, site_id, rider_id, total_orders, completed_orders,
                rejected_orders, on_time_orders, total_cost
            ))
    
    # 插入配送数据
    cursor.executemany('''
        INSERT INTO delivery_records 
        (date, site_id, rider_id, total_orders, completed_orders, rejected_orders, on_time_orders, total_cost)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', delivery_data)
    
    conn.commit()
    
    # 验证数据
    cursor.execute('SELECT COUNT(*) FROM delivery_records')
    record_count = cursor.fetchone()[0]
    
    print(f"✅ 数据库设置完成！")
    print(f"📊 生成 {record_count} 条配送记录")
    print(f"💾 数据库文件: logistics.db")
    
    # 显示示例数据
    print(f"\n📋 数据示例:")
    cursor.execute('''
        SELECT date, site_id, total_orders, 
               ROUND(completed_orders * 100.0 / total_orders, 2) as completion_rate,
               ROUND(rejected_orders * 100.0 / total_orders, 2) as rejection_rate
        FROM delivery_records 
        ORDER BY date DESC 
        LIMIT 5
    ''')
    
    for row in cursor.fetchall():
        print(f"   {row[0]} | {row[1]} | 订单:{row[2]} | 完成率:{row[3]}% | 拒收率:{row[4]}%")
    
    conn.close()

if __name__ == "__main__":
    setup_database()