
# 物流运营数据监控平台DEMO，通过可视化看板实时展示站点KPI指标，帮助管理者进行日/周复盘和成本优化。

## 功能特点
- 📊 实时监控完成率、拒收率、ETA达成率
- 📈 数据可视化图表展示
- 🚨 自动标识异常站点
- 💰 单均成本分析

1. 
   cd C:\Users\zhu\OneDrive\Desktop\GOFODEMO
   python database\setup_database.py

2. 
   cd backend
   python main.py
   （保持此窗口打开）

3. 
 index.html

